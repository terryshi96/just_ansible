# Examples

## Configuration Examples

* `local-cluster` : Sample configuration of a 3-node Teleport cluster using
  just a single machine

## Daemon Configuration

* `systemd` : Service file for systemd
* `upstart` : Start-up script for [upstart](https://en.wikipedia.org/wiki/Upstart)

## AWS examples

* `aws` : Examples of provisioning Teleport on AWS.


